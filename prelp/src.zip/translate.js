var new_lang = {

    "lt0": "LOVE",

    "lt1": "CELEBS",

    "lt2": "BEAUTY",

    "lt3": "GIFT IDEAS",

    "lt4": "Der Grund, warum jeder Juror von „Die Höhle der Löwen“ dieses Produkt unterstützt!",

    "lt5": "<b>(ARD,<script>document.write(dayNames[now.getDay()] + \", \" + now.getDate() + \" \" +monthNames[now.getMonth()] + \" \" + now.getFullYear());</script>Montag, 17 Juni 2019</b>- Es war die meistgesehene Folge in der Geschichte von „Die Höhle der Löwen“ – die Schwestern Anna und Janina Martin konnten mit ihrem einzigartigen Produkt die gesamte Jury überzeugen.",

    "lt6": "<span style=\"float: left; color: rgb(0, 0, 0); font-size: 68px; line-height: 35px; padding-top: 3px; padding-right: 3px; font-family: Times,serif,Georgia;\">N</span>och nie zuvor hat sich die gesamte Jury der „Höhle der Löwen“ unabhängig voneinander dazu entschlossen Millionen von Euros in eine mögliche Firma zu investieren",

    "lt7": "Nachdem die Jury unglaubliche 25% an Anteilen der Firma der Schwestern gekauft hatte, halfen sie den beiden persönlich ein re-branding und ein re-packing ihres Wunderproduktes vorzunehmen.",

    "lt8": "Ihr Produkt priesen die beiden Schwestern als<i>„größten Schritt in der Geschichte des Gewichtsabnehmens“</i>an und überzeugten die Jury so davon, ihr hart verdientes Geld in die Unternehmer-Geschwister zu investieren.",

    "lt9": "<i>„Wir waren geschockt. Wir hatten eigentlich nur damit gerechnet ein paar Ratschläge zu bekommen. Wir waren uns nicht mal sicher, ob wir überhaupt einen Investor überzeugen könnten.“</i>, sagte Janina nach Ausstrahlung der Folge.",

    "lt10": "Nach unglaublichen Angeboten der einzelnen Investoren brachen die Schwestern in Tränen aus.",

    "lt11": "<i>„Es fühlte sich nicht real an. Die Tatsache, dass all diese erfolgreichen, geschäftstüchtigen Menschen ein Teil von unserem Projekt sein wollten und ihr eigenes Geld dafür investieren wollten war unglaublich und sehr emotional für uns!“</i>erklärt Anna.",

    "lt12": "Die Schwestern sind die ersten Teilnehmer in der langen Laufzeit der Show, die Standing Ovations und Investitionen von allen Jury-Mitgliedern erhielten. Die beiden gaben an, nach dem Abschluss der Folge ihren Erfolg mit Champagner und Kuchen gefeiert zu haben.",

    "lt13": "Seit dem diese unglaubliche Folge aufgezeichnet wurde sind die beiden Schwestern hart am Arbeiten und nutzen die Tipps ihrer Investoren.",

    "lt14": "<i>„Wir haben unsere Firma komplett re-branded und haben uns eine neue Verpackung überlegt.“</i>sagt Anna.",

    "lt15": "Die beiden haben ihr Produkt, mit dem sie Millionen von Euros an Investorengeldern einnahmen, vor kurzem bekannt gegeben.",

    "lt16": "<i>„Das Produkt, welches wir in der Show gezeigt haben, wurde jetzt in<a href=\"{url}\"><b><u>Reduslim</u></b></a>rebranded. Es hat die Original Formel – alles was wir geändert haben sind der Name und die Verpackung.“</i>erklärt Janina.",

    "lt17": "Die beiden starteten den Produktverkauf durch ihre Firmen-Website und waren innerhalb 5 Minuten ausverkauft.",

    "lt18": "<i>„Wir haben sogar extra mehr Ware produziert als wir verkaufen konnten – dachten wir zumindest. Wir haben aber tatsächlich alles innerhalb von 5 Minuten verkauft!“</i>freute sich Anna.",

    "lt19": "Während die „Höhle der Löwen“-Juroren auf ihre clevere Investition anstoßen, schwärmen Frauen online von Reduslim und sagen, dass die Resultate dieses Produktes ihr Leben verändert haben.",

    "lt20": "Klinische Versuche von<a href=\"{url}\">Reduslim</a>haben herausstellen können, dass Frauen die dieses Produkt nutzen ihren Fettanteil drastisch reduzieren konnten und das dies auch, bei weiterer Nutzung, so bleibt.",

    "lt21": "<i>„Reduslim revolutioniert die Medizin des Gewicht Abnehmens,“</i>erklärt Judith Williams von der „Höhle der Löwen“.",

    "lt22": "Promis LIEBEN Reduslim",

    "lt23": "“Reduslim ist unglaublich. Das ist das einzige Unternehmen, welches die Fett-Produktion effektiv blockieren kann – und das in einer gesunden und sicheren Art und Weise.“ -<b>Maite Kelly</b>",

    "lt24": "„Ich nutze Reduslim seit Monaten al seine präventive Maßnahme und ich bin erstaunt, in was für einem guten Zustand mein Körper seitdem ist. Ich habe mich noch nie so gesund und schön gefühlt!“ -<b>Kaley Cuoco (bekannt als Penny aus der Serie \"Big Bang Theory\")</b>",

    "lt25": "„Ich habe einen sehr hektischen Zeitplan und dadurch nicht viel Zeit für Sport. Genau deshalb liebe ich Reduslim! Nur ein paar Minuten am Morgen und am Abend und mein Körper bleibt gesund und schön!“ -<b>Sandra Bullock</b>",

    "lt26": "„Ich liebe leckeres Essen und ich habe dutzende Gewichts-Abnahme-Produkte versucht. Ich bin süchtig! Aber nichts funktioniert nur halb so gut wie Reduslim. Ich hatte einige Falten an meinem Bauch und Rücken, welche ein paar Wochen, nachdem ich mit Reduslim angefangen habe, weg waren!“ -<b>Eva Longoria</b>",

    "lt27": "Gib dir selbst die Promi Behandlung",

    "lt28": "Für eine kurze Zeit gibt es Reduslim wieder vorrätig und jeder kann es probieren!",

    "lt29": "Du liest richtig, Reduslim, das Produkt, dass überall ausverkauft ist, gibt es wieder zu KAUFEN.",

    "lt30": "Aktuell gibt es das Produkt online sogar drastisch reduziert! Die magische Flasche wird dann direkt zu dir nach Hause geliefert und du kannst sie dann gleich nutzen.",

    "lt31": "Denk dran, dass du<a href=\"{url}\">Reduslim</a>nutzt, um das komplette Fett-Verbrennungs-Erlebnis zu erreichen.",

    "lt32": "Dieses Angebot gilt nicht lange, also folge dem Link hier drunter und sichere dir heute noch deine VORTEILSANGEBOT bevor es vergriffen ist!",

    "lt33": "Gesponserter Inhalt von Reduslim zur Verfügung gestellt",

    "lt34": "LESER-RESULTATE",

    "lt35": "Laura J., 50 Jahre, hat dieses Foto von ihren Resultaten mit Reduslim eingeschickt. Du siehst großartig aus, Laura!",

    "lt36": "<a href=\"{url}\" onclick=\"\"><b><u>„Reduslim</u></b></a>ist das absolut beste Produkt für die Gewichtsabnahme, das ich je benutzt habe. Ich dachte, meine schlanken Tage wären längst Geschichte. Ich kann euch dafür wirklich nicht genug danken!“",

    "lt37": "Laura J.<br>",

    "lt38": "VORHER &amp; NACHHER",

    "lt39": "„Ich versuchte praktisch über meine komplette Pubertät hinweg, mein Bauchfett loszuwerden. Reduslim hat das in einem Monat geschafft. Vielen Dank!“",

    "lt40": "Jessica S.<br>",

    "lt41": "VORHER &amp; NACHHER",

    "lt42": "„Zum ersten Mal in einer Ewigkeit bin ich endlich glücklich, wenn ich jeden Morgen in den Spiegel sehe. Ich habe mich seit Jahrzehnten nicht so selbstsicher gefühlt!“",

    "lt43": "Tiffany C.<br>",

    "lt44": "VORHER &amp; NACHHER",

    "lt45": "„Gott sei Dank habe ich dieses Gewichtheben nicht durchgezogen … Ich habe dieselben Resultate für weniger als eine Tasse Kaffee bekommen!“",

    "lt46": "Christina Novotney<br>",

    "lt47": "VORHER &amp; NACHHER",

    "lt48": "„Ich benutze Reduslim erst seit 2 Wochen und ich liebe es!!!!!!!! Ich habe sichtbare Veränderungen an meinem Körper festgestellt und, das Beste daran ist, mein Mann hat mir Komplimente wegen meiner Figur nach nur 2 Wochen gemacht!!!!! Er dachte, ich hatte eine Fettabsaugung und natürlich hatte ich das nicht, ist das nicht großartig!!!!!!!!“",

    "lt49": "Carol Keeton<br>",

    "lt50": "VORHER &amp; NACHHER",

    "lt51": "„Ich habe Reduslim benutzt und bin unglaublich beeindruckt von den Resultaten! Mein Bauch ist flacher und es fällt wirklich auf, dass meine Haut straffer geworden ist.“",

    "lt52": "Briana Smith<br>",

    "lt53": "VORHER &amp; NACHHER",

    "lt54": "„JA!! Endlich habe ich ein Produkt zur Gewichtsabnahme gefunden, das funktioniert. Im Alter von 33 Jahren, ist es das erste Mal, dass ein Produkt bei mir funktioniert.“",

    "lt55": "Angie Clayton<br>",

    "lt56": "Spezialangebot",

    "lt57": "Schritt 1:",

    "lt58": "Hier gehts zum SONDERANGEBOT!",

    "lt59": "Limitierte Stückzahl. Schnell bestellen.<br>Dieses Spezial-Angebot endet am:<script>document.write(dayNames[now.getDay()] + \", \" + now.getDate() + \" \" +monthNames[now.getMonth()] + \" \" + now.getFullYear());</script>Montag, 17 Juni 2019",

    "lt60": "JETZT ZUM ANGEBOT!",

    "lt61": "(REDUZIERTE FLASCHEN SIND TÄGLICH VERGRIFFEN – SICHERN SIE SICH IHRE JETZT SOFORT, BEVOR SIE ALLE WEG SIND)",

    "lt62": "WICHTIG: Durch klinische Tests wurde bewiesen, dass Sie dieses Produkt TÄGLICH benutzen MÜSSEN, um ähnliche Resultate zu erhalten.",

    "lt63": "<img src=\"src/checkmark-green-sm.png\"><strong>Update:</strong><span class=\"red-text\">Nur 2 Proben noch verfügbar.</span>Rabattaktion endet heute Nacht!",

    "lt64": "Schritt 1:<a href=\"{url}\"><b><u>Hier gehts zum SONDERANGEBOT!</u></b></a>",

    "lt65": "JETZT ZUM ANGEBOT!",

    "lt66": "Nutze den Vorteil unseres exklusiven Links und bezahle nur für die Lieferkosten!",

    "lt67": "Dieses Spezial-Angebot endet am:<script>document.write(dayNames[now.getDay()] + \", \" + now.getDate() + \" \" +monthNames[now.getMonth()] + \" \" + now.getFullYear());</script>Montag, 17 Juni 2019",

    "lt68": "Top-Kommentare",

    "lt69": "Kommentieren...",

    "lt70": "Tohloria Lewis",

    "lt71": "Ich nehme diese Fettverbrenner-Pille jetzt seit 3 Wochen und ich habe ernsthaft 9,1 kg verloren! Zwar nicht so gut wie Anna und Trevor, aber ich freue mich trotzdem darüber, weil der Versand weniger als 5 Mäuse gekostet hat! Mein Rücken- und Bauchfett schmilzt mit jedem Tag mehr dahin. Vielen Dank für diesen Bericht!",

    "lt72": "Antworten.<span class=\"like\">13 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt73": "Tanya Porquez",

    "lt74": "Ich habe Anna und Trevor kürzlich in den Nachrichten gesehen, als sie Reduslim vorgestellt haben und ich benutze die Pille noch immer. Ich benutze diese Produkte jetzt seit ungefähr 6 Wochen. Ernsthaft, es ist unglaublich, ich sage nur WOW.",

    "lt75": "Antworten.<span class=\"like\">6 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt76": "Jennifer Jackson Mercer",

    "lt77": "Ein Freund hat es benutzt und es mir vor 3 Wochen empfohlen. Ich habe das Produkt bestellt und innerhalb von 3 Tagen erhalten. Die Resultate waren unglaublich und ich kann es kaum erwarten, was 3 oder 4 Wochen ausmachen werden.",

    "lt78": "Antworten.<span class=\"like\">19 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt79": "Kristy Cash",

    "lt80": "Ich kann nicht glauben, dass das wirklich funktioniert! Ich bin sehr zufrieden, nachdem ich dieses Produkt benutzt habe.",

    "lt81": "Antworten.<span class=\"like\">Gefällt mir.</span><span class=\"time\"></span>",

    "lt82": "Katy Barrott",

    "lt83": "Ich habe das in den Nachrichten gesehen. Wie viel Glück hat Kim, dass sie diese Möglichkeit bekommen hat!?!?! Danke für den Artikel! Ich habe gerade meine Flasche bestellt",

    "lt84": "Antworten.<span class=\"like\">43 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt85": "Amanda Gibson",

    "lt86": "Meine Schwester hat das vor ein paar Monaten gemacht, ich habe mit meiner Bestellung gewartet, um zu sehen, ob es wirklich funktioniert und dann haben sie plötzlich keine Probeflaschen mehr gehabt! das war wirklich dumm von mir. bin froh, dass die Probeflaschen wieder erhältlich sind, den Fehler mache ich nicht noch einmal.",

    "lt87": "Antworten.<span class=\"like\">3 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt88": "Julie Keyse",

    "lt89": "Das ist toll!",

    "lt90": "Antworten.<span class=\"like\">Gefällt mir.</span><span class=\"time\"></span>",

    "lt91": "Sarah Williams",

    "lt92": "Ich werde dieses Produkt und den Zauber dahinter ausprobieren. Ich habe alles andere ausprobiert, das es gibt und bisher war nichts gut genug, um mir zu helfen.",

    "lt93": "Antworten.<span class=\"like\">12 . Gefällt mir.</span><span class=\"time\"></span>",

    "lt94": "# social plugin",

    "lt95": "© 2018 Copyright. All Rights reserved.",

    "lt96": "X",

    "lt97": "Verpassen Sie nicht dieses Angebot!",

    "lt98": "Reduziere die cm mit diesem von Maite Kelly empfohlenen Produkt",

    "lt99": "Nur noch<font color=\"red\">6</font>Flaschen heute!",

    "lt100": "Anspruch Rabatt Flasche<br>",

    "lt101": "Nutzen Sie unseren exklusiven Link, um noch heute SALE-Flaschen zu erhalten",

    "lt102": "Germany"
};

function Translater() {
    for (class_name in new_lang) {
        var elements = document.getElementsByClassName(class_name);
        if (elements.length) {
            for (key in elements) {
                elements[key].innerHTML = new_lang[class_name];
            }
        }
    }
};

//WOW！Why Every Judge Backed Up This Product??!!
//var dayNames = new Array("Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag");
//var monthNames = new Array( "Januar", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember");
//zeitbegrenztes angebot fur undere lesser
//customer satisfaction
//garanteed